package com.charity.charity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CharityApplicationTests {

	@Test
	void contextLoads() {
	}

}
