# Community-Cares
A web-based application using React and Springboot that serves as a platform for charities and individuals to create fundraising campaigns. The application provides features for users to discover, contribute to, and track various fundraising campaigns. Users can view their details and the details of the campaigns and can share the campaign on whatsapp also.An admin interface is also developed where admin can accept or reject the campaign. Users will be notified through email whenever the campaign is accepted/rejected.

